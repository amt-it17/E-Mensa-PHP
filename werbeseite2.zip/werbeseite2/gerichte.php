<?php


$gerichte = [
    [
        'name' => 'Rindfleisch mit Bambus, Kaiserschoten und rotem Paprika, dazu Mie Nudeln',
        'preis_intern' => 3.50,
        'preis_extern' => 6.20,
        'bild' => 'img1.jpeg'
    ],
    [
        'name' => 'Spinatrisotto mit kleinen Samosateigecken und gemischter Salat',
        'preis_intern' => 2.90,
        'preis_extern' => 5.30,
        'bild' => 'img2.jpeg'
    ],
    [
        'name' => 'Pizza Margherita',
        'preis_intern' => 4.50,
        'preis_extern' => 7.00,
        'bild' => 'img3.jpeg'
    ],
    [
        'name' => 'Hähnchen mit Reis und Gemüse',
        'preis_intern' => 5.20,
        'preis_extern' => 7.80,
        'bild' => 'img4.jpeg'
    ],
    [
        'name' => 'Eru mit Water Fufu',
        'preis_intern' => 5.50,
        'preis_extern' => 8.50,
        'bild' => 'img6.jpeg'
    ],
    [
        'name' => 'Ndolé mit Kochbananen',
        'preis_intern' => 5.90,
        'preis_extern' => 8.90,
        'bild' => 'img5.jpeg'
    ]
];