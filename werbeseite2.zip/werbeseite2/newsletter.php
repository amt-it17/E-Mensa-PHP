<?php


// Formulardaten empfangen
$name = trim($_POST['vorname'] ?? '');
$email = trim($_POST['email'] ?? '');
$sprache = $_POST['sprache'] ?? '';
$datenschutz = $_POST['datenschutz'] ?? '';

// Eingaben überprüfen
$fehler = [];

// Name überprüfen
if ($name === '') {
    $fehler[] = "Bitte geben Sie einen Namen ein.";
}

// Datenschutz überprüfen
if ($datenschutz !== 'zugestimmt') {
    $fehler[] = "Bitte stimmen Sie den Datenschutzbestimmungen zu.";
}

// E-Mail überprüfen
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $fehler[] = "Ihre E-Mail entspricht nicht den Vorgaben.";
}

// Verbotene E-Mail-Domains überprüfen
$emailKlein = strtolower($email);

if (str_ends_with($emailKlein, '@wegwerfmail.de') ||
    str_contains($emailKlein, '@trashmail.')) {

    $fehler[] = "Diese E-Mail-Domain ist nicht erlaubt.";
}

// Sprache überprüfen
if ($sprache !== 'de' && $sprache !== 'en') {
    $fehler[] = "Bitte wählen Sie eine gültige Sprache.";
}

// Daten speichern, wenn keine Fehler vorhanden sind
if (count($fehler) === 0) {

    $datei = __DIR__ . '/newsletter_anmeldungen.csv';

    $handle = fopen($datei, 'a');

    if ($handle === false) {

        $fehler[] = "Die Daten konnten nicht gespeichert werden.";

    } else {

        $gespeichert = fputcsv(
            $handle,
            [$name, $email, $sprache],
            ';',
            '"',
            ''
        );

        fclose($handle);

        if ($gespeichert === false) {
            $fehler[] = "Die Daten konnten nicht gespeichert werden.";
        }
    }
}

// Erfolgsmeldung oder Fehlermeldung
if (count($fehler) > 0) {

    $meldung = implode(' ', $fehler);
    $erfolg = false;

} else {

    $meldung = "Vielen Dank, " . $name .
        "! Ihre Anmeldung wurde erfolgreich ";

    $erfolg = true;
}

// Webseite wieder anzeigen
include __DIR__ . '/werbeseite.php';